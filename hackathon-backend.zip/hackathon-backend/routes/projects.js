const express = require('express');
const router = express.Router();
const Project = require('../models/Project');
const admin = require('../config/firebase');

// Middleware para verificar o token do Firebase
async function verifyFirebaseToken(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader) {
    return res.status(401).json({ message: 'Access denied. No token provided.' });
  }

  const token = authHeader.split(' ')[1];

  try {
    const decoded = await admin.auth().verifyIdToken(token);
    req.user = decoded;
    next();
  } catch (error) {
    console.error(error);
    return res.status(403).json({ message: 'Invalid Firebase token.' });
  }
}

// Rota para criar novo projeto
router.post('/', verifyFirebaseToken, async (req, res) => {
  const { title, description } = req.body;

  try {
    const project = new Project({
      user: req.user.uid,
      title,
      description
    });

    await project.save();
    res.status(201).json({ message: 'Project submitted successfully', project });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
