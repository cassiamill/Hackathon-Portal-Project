const admin = require('firebase-admin');
const serviceAccount = require('./hackathonaut-firebase-adminsdk-fbsvc-836b4cc6b2.json');

// Inicializa o Firebase com a conta de serviço
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});

module.exports = admin;
